var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'andrewtruex',
applicationName: 'my-first-app',
appUid: 'dxQCcR4XFqtC8ZP89n',
orgUid: '14RcyXqD6lvBQRgZHt',
deploymentUid: 'c2bf90eb-7575-4dd9-bdca-95feced7b93e',
serviceName: 'my-first-app',
shouldLogMeta: true,
disableAwsSpans: false,
disableHttpSpans: false,
stageName: 'dev',
pluginVersion: '3.5.0',
disableFrameworksInstrumentation: false})
const handlerWrapperArgs = { functionName: 'my-first-app-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
